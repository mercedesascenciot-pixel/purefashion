import { Category } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'polos-y-camisetas',
    name: 'Polos y camisetas',
    slug: 'polos-y-camisetas',
    description: 'Básicos esenciales, cortes oversize y polos de algodón suave de máxima comodidad.',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80',
    count: 4
  },
  {
    id: 'blusas',
    name: 'Blusas',
    slug: 'blusas',
    description: 'Blusas elegantes, satinadas y casuales ideales para oficina y eventos especiales.',
    image: 'https://images.unsplash.com/photo-1564257631407-4deb1f99d992?w=800&auto=format&fit=crop&q=80',
    count: 4
  },
  {
    id: 'pantalones-y-jeans',
    name: 'Pantalones y jeans',
    slug: 'pantalones-y-jeans',
    description: 'Cortes wide leg, mom jeans, palazzo y pantalones de vestir que estilizan tu silueta.',
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=80',
    count: 3
  },
  {
    id: 'vestidos',
    name: 'Vestidos',
    slug: 'vestidos',
    description: 'Vestidos casuales, midis y de noche con caídas fluidas y diseños femeninos.',
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&auto=format&fit=crop&q=80',
    count: 3
  },
  {
    id: 'faldas',
    name: 'Faldas',
    slug: 'faldas',
    description: 'Faldas plisadas, denim, corte en A y faldas midi versátiles para todo clima.',
    image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=800&auto=format&fit=crop&q=80',
    count: 2
  },
  {
    id: 'casacas-y-chaquetas',
    name: 'Casacas y chaquetas',
    slug: 'casacas-y-chaquetas',
    description: 'Casacas acolchadas, blazers estructurados, chaquetas denim y abrigos contemporáneos.',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&auto=format&fit=crop&q=80',
    count: 3
  },
  {
    id: 'conjuntos',
    name: 'Conjuntos',
    slug: 'conjuntos',
    description: 'Coordinados de dos piezas armónicos que simplifican tu outfit diario.',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&auto=format&fit=crop&q=80',
    count: 3
  },
  {
    id: 'ropa-deportiva',
    name: 'Ropa deportiva',
    slug: 'ropa-deportiva',
    description: 'Leggings compresivos, tops transpirables y joggers confortables para moverte libre.',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&auto=format&fit=crop&q=80',
    count: 2
  },
  {
    id: 'ropa-de-temporada',
    name: 'Ropa de temporada',
    slug: 'ropa-de-temporada',
    description: 'Sweaters tejidos, cardigans abrigadores y capas perfectas para el clima andino de Puno.',
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=800&auto=format&fit=crop&q=80',
    count: 2
  },
  {
    id: 'accesorios-de-moda',
    name: 'Accesorios de moda',
    slug: 'accesorios-de-moda',
    description: 'Cinturones de cuero sintético fino, carteras de hombro, pañoletas y bufandas de lana.',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80',
    count: 2
  }
];
